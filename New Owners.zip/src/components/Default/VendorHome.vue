<template>
    <div class="container p-8 mx-auto max-w-7xl">
        <div class="grid grid-cols-2 gap-5 md:grid-cols-4">
            <router-link to="/product">
                <img src="/img/food.png" class="w-72 h-88" alt="">
                <div class="flex justify-between mt-2">
                    <p class="text-xs font-light">Aday oldmeal</p>
                    <img src="/img/icons/favourite-border.svg" class="w-6 h-6" alt="">
                </div>
                <p class="font-medium">USD $16.00</p>
                <a href="#" class="mt-2 text-xs text-gray-500 underline">Maame Abena's Kitchen</a>
            </router-link>
            <router-link to="/product">
                <img src="/img/food.png" class="w-72 h-96" alt="">
                <div class="flex justify-between mt-2">
                    <p class="text-xs font-light">Aday oldmeal</p>
                    <img src="/img/icons/favourite-border.svg" class="w-6 h-6" alt="">
                </div>
                <p class="font-medium">USD $16.00</p>
                <a href="#" class="mt-2 text-xs text-gray-500 underline">Maame Abena's Kitchen</a>
            </router-link>
            <router-link to="/product">
                <img src="/img/food.png" class="w-72 h-96" alt="">
                <div class="flex justify-between mt-2">
                    <p class="text-xs font-light">Aday oldmeal</p>
                    <img src="/img/icons/favourite-border.svg" class="w-6 h-6" alt="">
                </div>
                <p class="font-medium">USD $16.00</p>
                <a href="#" class="mt-2 text-xs text-gray-500 underline">Maame Abena's Kitchen</a>
            </router-link>
            <router-link to="/product">
                <img src="/img/food.png" class="w-72 h-96" alt="">
                <div class="flex justify-between mt-2">
                    <p class="text-xs font-light">Aday oldmeal</p>
                    <img src="/img/icons/favourite-border.svg" class="w-6 h-6" alt="">
                </div>
                <p class="font-medium">USD $16.00</p>
                <a href="#" class="mt-2 text-xs text-gray-500 underline">Maame Abena's Kitchen</a>
            </router-link>
            <router-link to="/product">
                <img src="/img/food.png" class="w-72 h-96" alt="">
                <div class="flex justify-between mt-2">
                    <p class="text-xs font-light">Aday oldmeal</p>
                    <img src="/img/icons/favourite-border.svg" class="w-6 h-6" alt="">
                </div>
                <p class="font-medium">USD $16.00</p>
                <a href="#" class="mt-2 text-xs text-gray-500 underline">Maame Abena's Kitchen</a>
            </router-link>
            
        </div>

    </div>
</template>
<script>
export default {
    name: 'VendorList'
}
</script>